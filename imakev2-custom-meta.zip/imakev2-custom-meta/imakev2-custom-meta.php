<?php
/**
 * Plugin Name: Imake V2 - Custom meta
 * Description: Menambahkan dan mengelola custom post meta melalui REST API.
 * Version: 1.0
 * Author: Muhammad Syah Hanifian
 */

function imakev2_custom_meta() {
    $meta_keys = [
        '_old_id' => 'number',
        'rank_math_focus_keyword' => 'string',
        'rank_math_title' => 'string',
        'rank_math_description' => 'string',
        '_yoast_wpseo_focuskw' => 'string',
        '_yoast_wpseo_title' => 'string',
        '_yoast_wpseo_metadesc' => 'string',
        'fifu_image_url' => 'string',
        'fifu_image_alt' => 'string',
        'json_ld' => 'string',
    ];

    foreach ($meta_keys as $key => $type) {
        register_post_meta('post', $key, [
            'show_in_rest' => true,
            'single' => true,
            'type' => $type,
            'auth_callback' => function() {
                return current_user_can('edit_posts');
            }
        ]);
    }
}

add_action('init', 'imakev2_custom_meta');